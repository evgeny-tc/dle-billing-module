1. Fork https://github.com/evgeny-tc/dle-billing-module

2. Клонируем форк себе на пк
```
git clone https://github.com/my_account/dle-billing-module
cd dle-billing-module
```
3. Создаем новую ветку
```
git checkout -b myfix
```
4. Создаем upstream на оригинальный проект
```
git remote add upstream https://github.com/evgeny-tc/dle-billing-module
```
5. Вносим правки в код 

6. Делаем коммит и отправляем правки
```
git add .
git commit -am "My fixes"
git push -u origin new_branch
```
7. Переходим в свой проект ```https://github.com/my_account/dle-billing-module``` и жмем кнопку Compare & pull

8. Описываем какую проблему решает pull request
