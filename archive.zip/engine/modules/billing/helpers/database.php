<?php
/**
 * DLE Billing
 *
 * @link          https://github.com/evgeny-tc/dle-billing-module
 * @author        dle-billing.ru <evgeny.tc@gmail.com>
 * @copyright     Copyright (c) 2012-2023
 */

Class Database
{
	/**
	 * Builder WHERE..
	 * @var string
	 */
	public string $where = '';

	/**
	 * Connect db
	 * @var
	 */
	public $db;

	/**
	 * String balance field in db
	 * @var
	 */
	public $BalanceField;

	/**
	 * Local time
	 * @var
	 */
	public $_TIME;

	function __construct( $db, $field, $time )
	{
		$this->db = $db;
		$this->BalanceField = $field;
		$this->_TIME = $time;
	}

	/**
	 * Users list
	 * @param $limit
	 * @return array
	 */
	public function DbSearchUsers( $limit = 100 )
	{
		$limit = intval( $limit );

		$answer = array();

		$this->db->query( "SELECT * FROM " . USERPREFIX . "_users " . $this->where . " order by " . $this->BalanceField . " desc limit " . $limit );

		while ( $row = $this->db->get_row() ) $answer[] = $row;

		return $answer;
	}

	/**
	 * Search users
	 * @param $search_str
	 * @return mixed
	 */
	public function DbSearchUserByName( string $search_str )
	{
		return $this->db->super_query( "SELECT * FROM " . USERPREFIX . "_users
											WHERE name = '" . $this->db->safesql( $search_str ) . "' or
											      email = '" . $this->db->safesql( $search_str ) . "'" );
	}

	/**
	 * Get refund row by id
	 * @param $refund_id
	 * @return mixed
	 */
	public function DbGetRefundById( $refund_id )
	{
		return $this->db->super_query( "SELECT * FROM " . USERPREFIX . "_billing_refund
											WHERE refund_id='" . intval( $refund_id ) . "'" );
	}

	/**
	 * Update refund status
	 * @param $refund_id
	 * @param $new_status
	 * @return void
	 */
	public function DbRefundStatus( $refund_id, $new_status = 0 )
	{
		$new_status = $new_status ? intval( $new_status ) : 0;

		$this->db->query( "UPDATE " . USERPREFIX . "_billing_refund
									SET refund_date_return='" . $new_status . "'
									WHERE refund_id='" . intval( $refund_id ) . "'" );

		return;
	}

	/**
	 * Delete refund row
	 * @param $refund_id
	 * @return void
	 */
	public function DbRefundRemore( $refund_id )
	{
		$this->db->query( "DELETE FROM " . USERPREFIX . "_billing_refund
									WHERE refund_id='" . intval( $refund_id ) . "'" );

		return;
	}

	/**
	 * Get count refund rows
	 * @return mixed
	 */
	public function DbGetRefundNum()
	{
		$result_count = $this->db->super_query( "SELECT COUNT(*) as count
													FROM " . USERPREFIX . "_billing_refund " . $this->where );

        return $result_count['count'];
	}

	/**
	 * Get refund rows
	 * @param $intFrom
	 * @param $intPer
	 * @return array
	 */
	public function DbGetRefund( $intFrom = 1, $intPer = 30 )
	{
		$this->parsPage( $intFrom, $intPer );

		$answer = array();

		$this->db->query( "SELECT * FROM " . USERPREFIX . "_billing_refund " . $this->where . "
								ORDER BY refund_id desc LIMIT {$intFrom},{$intPer}" );

		while ( $row = $this->db->get_row() ) $answer[] = $row;

		return $answer;
	}

	/**
	 * Get count invoices
	 * @return mixed
	 */
	public function DbGetInvoiceNum()
	{
		$result_count = $this->db->super_query( "SELECT COUNT(*) as count
													FROM " . USERPREFIX . "_billing_invoice " . $this->where );

        return $result_count['count'];
	}

	/**
	 * Get sum invoice null
	 * @return int
	 */
	public function DbNewInvoiceSumm()
	{
		$sqlInvoice = $this->db->super_query( "SELECT SUM(invoice_get) as `sum`
													FROM " . USERPREFIX . "_billing_invoice
													WHERE invoice_get > '0' and invoice_date_pay > " . mktime(0,0,0) );

		return $sqlInvoice['sum'] ? $sqlInvoice['sum'] : 0;
	}

	/**
	 * Get invoice rows
	 * @param $intFrom
	 * @param $intPer
	 * @return array
	 */
	public function DbGetInvoice( $intFrom = 1, $intPer = 30 )
	{
		$this->parsPage( $intFrom, $intPer );

		$answer = array();

		$this->db->query( "SELECT * FROM " . USERPREFIX . "_billing_invoice " . $this->where . "
								ORDER BY invoice_id desc LIMIT {$intFrom},{$intPer}" );

		while ( $row = $this->db->get_row() ) $answer[] = $row;

		return $answer;
	}

	/**
	 * Get count transactions
	 * @return mixed
	 */
	public function DbGetHistoryNum()
	{
		$result_count = $this->db->super_query( "SELECT COUNT(*) as count
													FROM " . USERPREFIX . "_billing_history " . $this->where );

        return $result_count['count'];
	}

	/**
	 * Get transaction rows
	 * @param $intFrom
	 * @param $intPer
	 * @return array
	 */
	public function DbGetHistory( $intFrom = 1, $intPer = 30 )
	{
		$this->parsPage( $intFrom, $intPer );

		$answer = array();

		$this->db->query( "SELECT * FROM " . USERPREFIX . "_billing_history " . $this->where . "
							ORDER BY history_id desc LIMIT {$intFrom},{$intPer}" );

		while ( $row = $this->db->get_row() ) $answer[] = $row;

		return $answer;
	}

	/**
	 * Delete transaction by row
	 * @param $history_id
	 * @return void
	 */
	public function DbHistoryRemoveByID(  int $history_id )
	{
		$this->db->query( "DELETE FROM " . USERPREFIX . "_billing_history WHERE history_id = '" . intval( $history_id ) . "'" );
	}

	/**
	 * Create invoice
	 * @param string $strPaySys
	 * @param string $strUser
	 * @param float $floatGet
	 * @param float $floatPay
	 * @param $payer_info
	 * @param string $handler
	 * @return mixed
	 */
	public function DbCreatInvoice( string $strPaySys, string $strUser, float $floatGet, float $floatPay = 0, $payer_info = '', string $handler = '' )
	{
		$this->parsVar( $strUser );

		$this->parsVar( $handler, "/[^.a-z:\s]/" );

		if( is_array( $payer_info ) )
		{
			foreach( $payer_info as $key => $info )
			{
				if( is_array($info) )
				{
					foreach($info as $info_key => $info_val)
					{
						$payer_info[$key][$info_key] = preg_replace('/[^ a-z&#;@а-я\d.]/ui', '', $info_val );
					}
				}
				else
				{
					$payer_info[$key] = preg_replace('/[^ a-z&#;@а-я\d.]/ui', '', $info);
				}
			}

			$payer_info = serialize( $payer_info );
		}
		else
			$payer_info = $this->db->safesql( $payer_info );

		$this->parsVar( $strPaySys, "/[^a-zA-Z0-9\s]/" );
		$this->parsVar( $floatGet, "/[^.0-9\s]/" );
		$this->parsVar( $floatPay, "/[^.0-9\s]/" );

		$this->db->query( "INSERT INTO " . USERPREFIX . "_billing_invoice
							(invoice_paysys, invoice_user_name, invoice_get, invoice_pay, invoice_date_creat, invoice_payer_info, invoice_handler) values
							('{$strPaySys}',  '{$strUser }', '{$floatGet}', '{$floatPay}', '{$this->_TIME}', '{$payer_info}', '{$handler}')" );

		return $this->db->insert_id();
	}

	/**
	 * Get invoice row
	 * @param $id
	 * @return false
	 */
	public function DbGetInvoiceByID( $id )
	{
		$id = intval( $id );

		if( ! $id ) return false;

		return $this->db->super_query( "SELECT * FROM " . USERPREFIX . "_billing_invoice WHERE invoice_id='" . $id . "'" );
	}

	/**
	 * Update invoice by id
	 * @param $invoice_id
	 * @param $wait
	 * @param $invoice_paysys
	 * @param $invoice_pay
	 * @param $check_payer_requisites
	 * @return void
	 */
	public function DbInvoiceUpdate( $invoice_id, $wait = false, $invoice_paysys = '', $invoice_pay = '', $check_payer_requisites = '' )
	{
		$time = ! $wait ? $this->_TIME : 0;

		$this->db->query( "UPDATE " . USERPREFIX . "_billing_invoice
									SET invoice_date_pay = '" . $time . "',
										invoice_paysys = '" . $invoice_paysys . "',
										invoice_pay = '" . $invoice_pay . "',
										invoice_payer_requisites = '" . $check_payer_requisites . "'
									WHERE invoice_id = '" . intval( $invoice_id ) . "'" );

		return;
	}

	/**
	 * Delete invoice by id
	 * @param $invoice_id
	 * @return void
	 */
	public function DbInvoiceRemove( $invoice_id )
	{
		$this->db->query( "DELETE FROM " . USERPREFIX . "_billing_invoice WHERE invoice_id='" . intval( $invoice_id ) . "'" );

		return;
	}

	/**
	 * Create refund row
	 * @param $strUser
	 * @param $floatSum
	 * @param $floatComm
	 * @param $strReq
	 * @return mixed
	 */
	public function DbCreatRefund( $strUser, $floatSum, $floatComm, $strReq )
	{
		$this->parsVar( $strUser );
		$this->parsVar( $strReq );
		$this->parsVar( $floatSum, "/[^.0-9\s]/" );
		$this->parsVar( $floatComm, "/[^.0-9\s]/" );

		$this->db->query( "INSERT INTO " . USERPREFIX . "_billing_refund
							(refund_date, refund_user, refund_summa, refund_commission, refund_requisites) values
							('" . $this->_TIME . "',
							 '" . $strUser . "',
							 '" . $floatSum . "',
							 '" . $floatComm . "',
							 '" . $strReq . "')" );

		return $this->db->insert_id();
	}

	/**
	 * Set params filter
	 * @param $where_array
	 * @return void
	 */
	public function DbWhere( array $where_array = [] )
	{
		$this->where = '';

		foreach( $where_array as $key => $value )
		{
			$this->parsVar( $value );

			if( empty( $value ) ) continue;

			$this->where .= ! $this->where ? "where " . str_replace("{s}", $value, $key) : " and " . str_replace("{s}", $value, $key);
		}

		return;
	}

	# Примеры фильтров:
	#		/[^-_рРА-Яа-яa-zA-Z0-9\s]/
	#		/[^a-zA-Z0-9\s]/
	#		/[^.0-9\s]/
	#
	/**
	 * Filter
	 * @param $str
	 * @param $filter
	 * @return void
	 */
	public function parsVar( &$str, $filter = '' )
	{
		if( is_array( $str ) )
		{
			foreach( $str as $item )
			{
				$this->parsVar( $item, $filter );
			}

			return;
		}

		$str = trim( $str );

		if( function_exists( "get_magic_quotes_gpc" ) && get_magic_quotes_gpc() ) $str = stripslashes( $str );

		$str = htmlspecialchars( trim( $str ), ENT_COMPAT );

		if( $filter )
		{
			$str = preg_replace( $filter, "", $str);
		}

		$str = preg_replace('#\s+#i', ' ', $str);
		$str = $this->db->safesql( $str );

		return $str;
	}

	function parsPage( &$intFrom, &$intPer )
	{
		$intFrom = intval( $intFrom );
		$intPer = intval( $intPer );

		if( $intFrom < 1 ) $intFrom = 1;
		if( $intPer < 1 ) $intPer = 30;

		$intFrom = ( $intFrom * $intPer ) - $intPer;

		return;
	}
}