<?php
/*
=====================================================
 Billing
-----------------------------------------------------
 evgeny.tc@gmail.com
-----------------------------------------------------
 This code is copyrighted
=====================================================
*/

if(!defined('DATALIFEENGINE')) {
  die("Hacking attempt!");
}

require_once DLEPlugins::Check(ENGINE_DIR . '/modules/billing/admin.php');